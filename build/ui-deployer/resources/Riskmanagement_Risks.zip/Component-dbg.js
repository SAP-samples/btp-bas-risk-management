sap.ui.define(["sap/fe/core/AppComponent"], function(AppComponent) {
    'use strict';

    return AppComponent.extend("RiskmanagementRisks.Component", {
        metadata: {
            manifest: "json"
        }
    });
});
